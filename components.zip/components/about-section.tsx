// "use client";

// import { useRef } from "react";
// import { motion, useScroll, useTransform } from "framer-motion";
// import { Badge } from "@/components/ui/badge";
// import { cn } from "@/lib/utils";

// const typewriterVariants = {
//   hidden: { opacity: 0 },
//   visible: {
//     opacity: 1,
//     transition: { staggerChildren: 0.1 },
//   },
// };

// const letterVariants = {
//   hidden: { opacity: 0, y: 20 },
//   visible: {
//     opacity: 1,
//     y: 0,
//     transition: { type: "spring", stiffness: 100 },
//   },
// };

// const AboutSection = () => {
//   const terminalRef = useRef(null);
//   const { scrollYProgress } = useScroll({
//     target: terminalRef,
//     offset: ["start end", "end start"],
//   });

//   const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1]);
//   const y = useTransform(scrollYProgress, [0, 1], [100, 0]);

//   const skills = [
//     "Docker 🐳",
//     "Kubernetes ⚓",
//     "AWS ☁️",
//     "Python 🐍",
//     "React ⚛️",
//     "Security 🔒",
//     "DevOps 🔄",
//     "Cloud Architecture 🏗️"
//   ];

//   const commands = ["whoami", "ls skills", "cat certifications.txt"];

//   const getCommandOutput = (cmd: string) => {
//     switch (cmd) {
//       case "whoami":
//         return `
// > Expert DevOps et Sécurité Numérique
// > 3 ans d'expérience
// > Passionné par l'automatisation
// > Spécialiste Cloud & CI/CD`;
//       case "ls skills":
//         return skills.join("\n");
//       case "cat certifications.txt":
//         return `
// TOIEC (2023)
// └── Score: B1*
// └── Issuer: Pigier Bénin
// └── Status: Certified 🏆`;
//       default:
//         return "Command not found";
//     }
//   };

//   const TerminalPrompt = () => (
//     <div className="flex items-center gap-2 text-primary font-mono">
//       <span>djamal@portfolio</span>
//       <span className="text-secondary">:~$</span>
//     </div>
//   );

//   const AnimatedSkillBadge = ({ skill }: { skill: string }) => (
//     <motion.div
//       whileHover={{
//         scale: 1.1,
//         rotate: [0, -5, 5, -5, 0],
//         transition: { duration: 0.3 },
//       }}
//       className="transform-gpu"
//     >
//       <Badge
//         variant="outline"
//         className={cn(
//           "border-primary/50 text-primary",
//           "hover:bg-primary hover:text-primary-foreground",
//           "transition-all duration-300",
//           "backdrop-blur-sm bg-background/50"
//         )}
//       >
//         {skill}
//       </Badge>
//     </motion.div>
//   );

//   return (
//     <div
//       className={cn(
//         "min-h-screen py-20 relative overflow-hidden",
//         "bg-gradient-to-b from-background to-background/95"
//       )}
//     >
//       {/* Animated background grid */}
//       <div className="absolute inset-0 opacity-20">
//         <div
//           className="absolute inset-0"
//           style={{
//             backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--primary)) 1px, transparent 0)`,
//             backgroundSize: "50px 50px",
//           }}
//         />
//       </div>

//       <motion.div
//         ref={terminalRef}
//         style={{ y, opacity }}
//         className="max-w-4xl mx-auto px-4"
//       >
//         <div
//           className={cn(
//             "rounded-lg shadow-2xl overflow-hidden",
//             "bg-card border border-primary/20",
//             "backdrop-blur-sm"
//           )}
//         >
//           {/* Terminal Header */}
//           <div
//             className={cn(
//               "p-3 flex items-center gap-2",
//               "bg-muted/50 border-b border-border"
//             )}
//           >
//             <div className="flex gap-2">
//               <div className="w-3 h-3 rounded-full bg-destructive" />
//               <div className="w-3 h-3 rounded-full bg-yellow-500" />
//               <div className="w-3 h-3 rounded-full bg-primary" />
//             </div>
//             <span className="text-muted-foreground text-sm font-mono ml-2">
//               portfolio.terminal
//             </span>
//           </div>

//           {/* Terminal Content */}
//           <div className="p-6 font-mono text-sm space-y-4">
//             {commands.map((cmd, index) => (
//               <motion.div
//                 key={cmd}
//                 initial="hidden"
//                 whileInView="visible"
//                 viewport={{ once: true }}
//                 variants={typewriterVariants}
//                 className="space-y-2"
//               >
//                 <div className="flex items-center gap-2">
//                   <TerminalPrompt />
//                   <motion.span
//                     variants={letterVariants}
//                     className="text-foreground"
//                   >
//                     {cmd}
//                   </motion.span>
//                 </div>
//                 <motion.pre
//                   className="text-primary/80 ml-4 whitespace-pre-wrap"
//                   variants={letterVariants}
//                 >
//                   {getCommandOutput(cmd)}
//                 </motion.pre>
//               </motion.div>
//             ))}

//             <div className="flex items-center gap-2">
//               <TerminalPrompt />
//               <span className="animate-pulse text-primary">█</span>
//             </div>
//           </div>
//         </div>

//         {/* Skills Grid */}
//         <motion.div
//           initial={{ opacity: 0, y: 50 }}
//           whileInView={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.5, delay: 0.2 }}
//           viewport={{ once: true }}
//           className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4"
//         >
//           {skills.map((skill) => (
//             <AnimatedSkillBadge key={skill} skill={skill} />
//           ))}
//         </motion.div>
//       </motion.div>
//     </div>
//   );
// };

// export default AboutSection;

"use client";

import { useState, useRef, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const AboutSection = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1]);
  const y = useTransform(scrollYProgress, [0, 1], [100, 0]);

  // État du navigateur
  const [activeTab, setActiveTab] = useState("about");
  const [url, setUrl] = useState("https://google.com/search?q=Djamal+DevOps");
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("Djamal DevOps");
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [showExtensions, setShowExtensions] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Données des compétences
  const skills = {
    "DevOps": [
      "Docker 🐳", "Kubernetes ⚓", "CI/CD Pipelines", "Terraform", "Ansible", 
      "GitLab CI", "Jenkins", "Prometheus/Grafana"
    ],
    "Cloud": [
      "AWS ☁️", "Google Cloud", "Azure Fundamentals", "Serverless", 
      "Architecture Cloud", "Solutions Distribuées"
    ],
    "Développement": [
      "Python 🐍", "React ⚛️", "TypeScript", "Node.js", "Bash", 
      "SQL/NoSQL", "API REST", "Microservices"
    ],
    "Sécurité": [
      "Sécurité Cloud 🔒", "OWASP Top 10", "Hardening", "Kubernetes Security", 
      "Politiques de Sécurité", "Audits"
    ]
  };

  const experiences = [
    {
      title: "DevOps Engineer",
      company: "Tech Solutions Inc.",
      period: "2021 - Présent",
      description: "Conception et maintenance d'infrastructures cloud, automatisation des déploiements, mise en place de pipelines CI/CD."
    },
    {
      title: "Ingénieur Système",
      company: "Data Systems Ltd.",
      period: "2019 - 2021",
      description: "Administration de serveurs Linux, virtualisation, sauvegardes et reprise après sinistre."
    }
  ];

  const certifications = [
    {
      name: "AWS Certified Solutions Architect",
      issuer: "Amazon Web Services",
      year: "2023"
    },
    {
      name: "Certified Kubernetes Administrator (CKA)",
      issuer: "Cloud Native Computing Foundation",
      year: "2022"
    },
    {
      name: "TOEIC (Score B1)",
      issuer: "Pigier Bénin",
      year: "2023"
    }
  ];

  // Effectuer une recherche
  const performSearch = () => {
    setIsLoading(true);
    setUrl(`https://google.com/search?q=${encodeURIComponent(searchQuery)}`);
    setHistory(prev => [...prev, searchQuery]);
    
    setTimeout(() => {
      setIsLoading(false);
    }, 800);
  };

  // Gestion du zoom
  const handleZoom = (direction: "in" | "out" | "reset") => {
    if (direction === "in" && zoomLevel < 150) {
      setZoomLevel(zoomLevel + 10);
    } else if (direction === "out" && zoomLevel > 50) {
      setZoomLevel(zoomLevel - 10);
    } else if (direction === "reset") {
      setZoomLevel(100);
    }
  };

  // Onglets du navigateur
  const tabs = [
    { id: "about", title: "Recherche Google - Djamal DevOps", icon: "🔍" },
    { id: "linkedin", title: "LinkedIn - Djamal DevOps", icon: "💼" },
    { id: "github", title: "GitHub - djamal-dev", icon: "👨‍💻" },
  ];

  // Extensions Chrome
  const extensions = [
    { name: "React Developer Tools", id: "react-dev-tools" },
    { name: "AWS Toolkit", id: "aws-toolkit" },
    { name: "Kubernetes Dashboard", id: "k8s-dashboard" },
  ];

  // Historique de navigation
  const historyItems = [
    "Djamal DevOps compétences",
    "Djamal DevOps expérience",
    "Djamal DevOps certifications",
    "Djamal DevOps contact"
  ];

  return (
    <div
      className={cn(
        "min-h-screen py-20 relative overflow-hidden",
        "bg-gradient-to-b from-background to-background/95"
      )}
    >
      {/* Fond animé */}
      <div>
        <div
          className="absolute inset-0"
          // style={{
          //   backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--primary)) 1px, transparent 0)`,
          //   backgroundSize: "50px 50px",
          // }}
        />
      </div>

      <motion.div
        ref={containerRef}
        // style={{ y, opacity }}
        className="max-w-6xl mx-auto px-4"
      >
        {/* Fenêtre Chrome */}
        <div
          className={cn(
            "rounded-lg shadow-2xl overflow-hidden",
            "bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700",
            "backdrop-blur-sm",
            "transition-all duration-300",
            "w-full"
          )}
          style={{ zoom: `${zoomLevel}%` }}
        >
          {/* Barre de titre Chrome */}
          <div
            className={cn(
              "flex items-center justify-between p-2",
              "bg-gray-100 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700",
              "cursor-default select-none"
            )}
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  className="w-5 h-5"
                >
                  <path
                    fill="#4285F4"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#34A853"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#EA4335"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setShowBookmarks(!showBookmarks)}
                  className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"
                    />
                  </svg>
                </button>
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </button>
              </div>
            </div>

            <div className="flex-1 flex justify-center">
              <div className="w-full max-w-2xl">
                {/* Barre d'adresse Chrome */}
                <div
                  className={cn(
                    "flex items-center rounded-full px-4 py-1",
                    "bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600",
                    "focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent"
                  )}
                >
                  <div className="flex items-center gap-2 w-full">
                    <button className="text-gray-500 dark:text-gray-400">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M10 19l-7-7m0 0l7-7m-7 7h18"
                        />
                      </svg>
                    </button>
                    <button className="text-gray-500 dark:text-gray-400">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M14 5l7 7m0 0l-7 7m7-7H3"
                        />
                      </svg>
                    </button>
                    <button className="text-gray-500 dark:text-gray-400">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                        />
                      </svg>
                    </button>
                    <input
                      type="text"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      className={cn(
                        "flex-1 bg-transparent outline-none text-sm",
                        "text-gray-700 dark:text-gray-200"
                      )}
                      onKeyPress={(e) => {
                        if (e.key === "Enter") performSearch();
                      }}
                    />
                    {isLoading ? (
                      <div className="w-4 h-4 border-2 border-gray-300 dark:border-gray-500 border-t-blue-500 rounded-full animate-spin"></div>
                    ) : (
                      <button
                        onClick={performSearch}
                        className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                          />
                        </svg>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleZoom("out")}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-400"
                title="Zoom out"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M20 12H4"
                  />
                </svg>
              </button>
              <span className="text-xs text-gray-600 dark:text-gray-400">
                {zoomLevel}%
              </span>
              <button
                onClick={() => handleZoom("in")}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-400"
                title="Zoom in"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4v16m8-8H4"
                  />
                </svg>
              </button>
              <button
                onClick={() => setShowExtensions(!showExtensions)}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-400"
                title="Extensions"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                  />
                </svg>
              </button>
              <div className="flex items-center gap-1">
                <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded text-gray-600 dark:text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                    />
                  </svg>
                </button>
                <button className="p-1 hover:bg-red-500 hover:text-white rounded text-gray-600 dark:text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Barre d'onglets Chrome */}
          <div className="flex bg-gray-200 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 text-sm relative max-w-xs truncate",
                  "border-r border-gray-300 dark:border-gray-700",
                  activeTab === tab.id
                    ? "bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                    : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700"
                )}
              >
                <span>{tab.icon}</span>
                <span className="truncate">{tab.title}</span>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500"></div>
                )}
                <button className="ml-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </button>
            ))}
            <button className="px-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                />
              </svg>
            </button>
          </div>

          {/* Barre de favoris */}
          {showBookmarks && (
            <div className="flex items-center px-2 py-1 bg-gray-100 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 text-xs">
              <span className="text-gray-500 dark:text-gray-400 mr-2">
                Favoris:
              </span>
              <a
                href="#about"
                className="text-blue-600 dark:text-blue-400 hover:underline mr-3"
              >
                Accueil
              </a>
              <a
                href="#skills"
                className="text-blue-600 dark:text-blue-400 hover:underline mr-3"
              >
                Compétences
              </a>
              <a
                href="#projects"
                className="text-blue-600 dark:text-blue-400 hover:underline mr-3"
              >
                Projets
              </a>
              <a
                href="#contact"
                className="text-blue-600 dark:text-blue-400 hover:underline"
              >
                Contact
              </a>
            </div>
          )}

          {/* Historique de navigation */}
          {showHistory && (
            <div className="absolute left-0 top-16 z-50 bg-white dark:bg-gray-800 shadow-lg rounded-md border border-gray-300 dark:border-gray-700 w-64 ml-2">
              <div className="p-2 border-b border-gray-200 dark:border-gray-700 font-medium text-sm">
                Historique
              </div>
              <div className="max-h-60 overflow-y-auto">
                {historyItems.map((item, index) => (
                  <div
                    key={index}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm flex items-center justify-between"
                  >
                    <span className="truncate">{item}</span>
                    <button 
                      onClick={() => {
                        setSearchQuery(item);
                        performSearch();
                        setShowHistory(false);
                      }}
                      className="text-blue-500 text-xs"
                    >
                      Visiter
                    </button>
                  </div>
                ))}
              </div>
              <div className="p-2 border-t border-gray-200 dark:border-gray-700 text-sm">
                <button className="text-blue-500">Effacer l&apos;historique</button>
              </div>
            </div>
          )}

          {/* Menu des extensions */}
          {showExtensions && (
            <div className="absolute right-2 top-16 z-50 bg-white dark:bg-gray-800 shadow-lg rounded-md border border-gray-300 dark:border-gray-700 w-64">
              <div className="p-2 border-b border-gray-200 dark:border-gray-700 font-medium text-sm">
                Extensions
              </div>
              <div className="max-h-60 overflow-y-auto">
                {extensions.map((ext) => (
                  <div
                    key={ext.id}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm flex items-center justify-between"
                  >
                    <span>{ext.name}</span>
                    <button className="text-blue-500 text-xs">Gérer</button>
                  </div>
                ))}
              </div>
              <div className="p-2 border-t border-gray-200 dark:border-gray-700 text-sm">
                <button className="text-blue-500">Visiter le Chrome Web Store</button>
              </div>
            </div>
          )}

          {/* Contenu de la page (résultats de recherche) */}
          <div
            className={cn(
              "bg-white dark:bg-gray-900",
              "min-h-[500px] p-6"
            )}
          >
            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="mt-4 text-gray-500 dark:text-gray-400">
                    Chargement des résultats...
                  </p>
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto">
                {/* Barre de recherche Google */}
                <div className="mb-8">
                  <div className="flex items-center justify-center">
                    <div className="w-full max-w-2xl">
                      <div className="relative">
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === "Enter") performSearch();
                          }}
                          className={cn(
                            "w-full px-5 py-3 rounded-full border border-gray-300 dark:border-gray-700",
                            "focus:outline-none focus:ring-2 focus:ring-blue-500",
                            "bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                          )}
                        />
                        <button
                          onClick={performSearch}
                          className="absolute right-3 top-3 text-gray-500 dark:text-gray-400"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Résultats de recherche */}
                <div className="space-y-6">
                  {/* Résultat 1 - Profil */}
                  <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold mr-3">
                        DJ
                      </div>
                      <div>
                        <h2 className="text-xl font-semibold text-blue-600 dark:text-blue-400">
                          Djamal DevOps - Profil Professionnel
                        </h2>
                        <p className="text-green-700 dark:text-green-400 text-sm">
                          https://portfolio.dev/djamal-devops
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300">
                      Expert DevOps et Sécurité Cloud avec 3 ans d&apos;expérience. Spécialisé dans
                      l&apos;automatisation des infrastructures, les pipelines CI/CD et les architectures
                      cloud sécurisées.
                    </p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <Badge variant="outline" className="text-blue-600 dark:text-blue-400">
                        AWS Certified
                      </Badge>
                      <Badge variant="outline" className="text-blue-600 dark:text-blue-400">
                        Kubernetes Expert
                      </Badge>
                      <Badge variant="outline" className="text-blue-600 dark:text-blue-400">
                        Sécurité Cloud
                      </Badge>
                    </div>
                  </div>

                  {/* Résultat 2 - Compétences */}
                  <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                    <h2 className="text-xl font-semibold text-blue-600 dark:text-blue-400 mb-2">
                      Compétences Techniques - Djamal DevOps
                    </h2>
                    <p className="text-green-700 dark:text-green-400 text-sm mb-3">
                      https://portfolio.dev/djamal-devops/competences
                    </p>
                    
                    {Object.entries(skills).map(([category, items]) => (
                      <div key={category} className="mb-4">
                        <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                          {category}
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {items.map((skill) => (
                            <Badge 
                              key={skill} 
                              variant="outline" 
                              className="text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Résultat 3 - Expérience */}
                  <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                    <h2 className="text-xl font-semibold text-blue-600 dark:text-blue-400 mb-2">
                      Expérience Professionnelle - Djamal DevOps
                    </h2>
                    <p className="text-green-700 dark:text-green-400 text-sm mb-3">
                      https://linkedin.com/in/djamal-devops
                    </p>
                    
                    <div className="space-y-4">
                      {experiences.map((exp, index) => (
                        <div key={index} className="pl-4 border-l-2 border-blue-200 dark:border-blue-800">
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {exp.title} · {exp.company}
                          </h3>
                          <p className="text-gray-500 dark:text-gray-400 text-sm mb-2">
                            {exp.period}
                          </p>
                          <p className="text-gray-600 dark:text-gray-300">
                            {exp.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Résultat 4 - Certifications */}
                  <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                    <h2 className="text-xl font-semibold text-blue-600 dark:text-blue-400 mb-2">
                      Certifications - Djamal DevOps
                    </h2>
                    <p className="text-green-700 dark:text-green-400 text-sm mb-3">
                      https://portfolio.dev/djamal-devops/certifications
                    </p>
                    
                    <div className="space-y-3">
                      {certifications.map((cert, index) => (
                        <div key={index} className="flex items-start">
                          <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full mr-3">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 text-blue-600 dark:text-blue-400"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                              />
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900 dark:text-white">
                              {cert.name}
                            </h3>
                            <p className="text-gray-500 dark:text-gray-400 text-sm">
                              {cert.issuer} · {cert.year}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recherches associées */}
                  <div className="pt-6">
                    <h3 className="font-medium text-gray-900 dark:text-white mb-3">
                      Recherches associées
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        "Djamal DevOps projets",
                        "Djamal DevOps AWS",
                        "Djamal DevOps Kubernetes",
                        "Djamal DevOps contact",
                        "Djamal DevOps GitHub",
                        "Djamal DevOps Docker",
                        "Djamal DevOps expérience",
                        "Djamal DevOps compétences techniques"
                      ].map((search) => (
                        <button
                          key={search}
                          onClick={() => {
                            setSearchQuery(search);
                            performSearch();
                          }}
                          className="text-left text-blue-600 dark:text-blue-400 hover:underline text-sm"
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Barre de statut Chrome */}
          <div
            className={cn(
              "flex items-center justify-between px-3 py-1 text-xs",
              "bg-gray-100 dark:bg-gray-800 border-t border-gray-300 dark:border-gray-700",
              "text-gray-600 dark:text-gray-400"
            )}
          >
            <div>
              {activeTab === "about" && "Résultats de recherche pour 'Djamal DevOps'"}
              {activeTab === "linkedin" && "LinkedIn - Djamal DevOps"}
              {activeTab === "github" && "GitHub - djamal-dev"}
            </div>
            <div>
              <span className="mr-3">Zoom: {zoomLevel}%</span>
              <span>Portfolio v2.0</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AboutSection;