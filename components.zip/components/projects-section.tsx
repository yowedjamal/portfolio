// "use client"

// import { useState } from "react"
// import { motion } from "framer-motion"
// import { Badge } from "@/components/ui/badge"
// import { Button } from "@/components/ui/button"
// import { Github, ExternalLink, Maximize2, MinusCircle } from "lucide-react"
// import Image from "next/image"
// import { cn } from "@/lib/utils"

// const PLACEHOLDER_IMAGES = {
//   visitbenin: "/images/visitbenin.png",
//   agency: "/images/aas.png",
//   frozen: "/images/congelato.png",
//   incubator: "/images/incubator.png",
// }

// const projects = [
//   {
//     title: "VisitBenin",
//     description:
//       "Plateforme de référencement des sites touristiques au bénin avec intégration d'un chatbot pour une expérience utilisateur interactive et personnalisée.",
//     image: PLACEHOLDER_IMAGES.visitbenin,
//     tags: ["Angular", "Cohere", "Laravel"],
//     github: "#",
//     demo: "https://visitbenin.djamal.site",
//   },
//   {
//     title: "MultiServices Agency",
//     description:
//       "Site vitrine moderne pour une agence multiservices spécialisée dans l'immobilier, la formation et la communication. Présentation détaillée des services et informations clés de l'agence.",
//     image: PLACEHOLDER_IMAGES.agency, // Image à placer dans public/images/
//     tags: ["Next.js", "Tailwind CSS", "TypeScript"],
//     github: "#",
//     demo: "https://aas.djamal.site",
//   },
//   {
//     title: "FrozenDelights",
//     description:
//       "Site vitrine élégant pour une boutique de produits surgelés, mettant en valeur les produits et l'histoire de l'entreprise à travers une interface utilisateur intuitive.",
//     image: PLACEHOLDER_IMAGES.frozen, // Image à placer dans public/images/
//     tags: ["React", "Styled Components", "Node.js"],
//     github: "#",
//     demo: "https://congelato.djamal.site",
//   },
//   {
//     title: "TechIncubator",
//     description:
//       "Plateforme de présentation d'un incubateur technologique d'une école, présentant les programmes, les startups incubées et les opportunités de mentorat.",
//     image: PLACEHOLDER_IMAGES.incubator, // Image à placer dans public/images/
//     tags: ["Next.js", "Framer Motion", "Prisma"],
//     github: "#",
//     demo: "https://incubator.djamal.site",
//   },
// ]

// const HologramProject = ({ project, index }: any) => {
//   const [isExpanded, setIsExpanded] = useState(false)
//   const [isHovered, setIsHovered] = useState(false)

//   return (
//     <motion.div
//       layout
//       initial={{ opacity: 0, scale: 0.8 }}
//       animate={{ opacity: 1, scale: 1 }}
//       transition={{
//         duration: 0.5,
//         delay: index * 0.2,
//         layout: { duration: 0.3 },
//       }}
//       className={cn("relative", isExpanded && "col-span-3 row-span-2")}
//     >
//       <div
//         className={cn(
//           "relative rounded-xl overflow-hidden",
//           "bg-gradient-to-r from-nav-gradient-from/30 to-nav-gradient-to/30 dark:from-dark-nav-gradient-from/30 dark:to-dark-nav-gradient-to/30",
//           "backdrop-blur-sm border border-primary/20",
//           "transition-all duration-500",
//           isExpanded ? "h-[600px]" : "h-[400px]",
//         )}
//         onMouseEnter={() => setIsHovered(true)}
//         onMouseLeave={() => setIsHovered(false)}
//       >
//         {/* Hologram Effect Overlay */}
//         <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-secondary/5 z-10" />
//         <div
//           className="absolute inset-0 opacity-30"
//           style={{
//             backgroundImage: `repeating-linear-gradient(0deg, 
//               transparent, 
//               transparent 2px, 
//               hsl(var(--primary)/.05) 2px, 
//               hsl(var(--primary)/.05) 4px)`,
//           }}
//         />

//         {/* Project Image with Effect */}
//         <motion.div
//           className="absolute inset-0 z-0"
//           animate={{
//             filter: isHovered ? ["brightness(1)", "brightness(1.2)", "brightness(1)"] : "brightness(1)",
//           }}
//           transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
//         >
//           <Image
//             src={project.image || "/placeholder.svg"}
//             alt={project.title}
//             fill
//             className={cn("object-cover mix-blend-luminosity", "opacity-40 dark:opacity-30")}
//           />
//         </motion.div>

//         {/* Content Container */}
//         <div className="relative z-20 p-6 h-full flex flex-col justify-between">
//           <div className="backdrop-blur-md bg-card/80 rounded-lg p-4">
//             <motion.div
//               className="flex justify-between items-start"
//               animate={{ y: isHovered ? 0 : 10, opacity: isHovered ? 1 : 0.8 }}
//             >
//               <h3 className={cn("text-2xl font-bold", "text-primary dark:text-primary-foreground")}>{project.title}</h3>
//               <Button
//                 variant="ghost"
//                 size="icon"
//                 onClick={() => setIsExpanded(!isExpanded)}
//                 className="text-primary hover:text-secondary transition-colors"
//               >
//                 {isExpanded ? <MinusCircle /> : <Maximize2 />}
//               </Button>
//             </motion.div>

//             <motion.p
//               className="mt-4 text-foreground dark:text-foreground/90 font-medium"
//               animate={{ opacity: isHovered ? 1 : 0.9 }}
//             >
//               {project.description}
//             </motion.p>
//           </div>

//           <motion.div
//             className="space-y-6 backdrop-blur-md bg-card/80 rounded-lg p-4 mt-4"
//             animate={{ y: isHovered ? 0 : 20, opacity: isHovered ? 1 : 0 }}
//           >
//             <div className="flex flex-wrap gap-2">
//               {project.tags.map((tag: string) => (
//                 <Badge
//                   key={tag}
//                   className={cn(
//                     "bg-primary/90 text-primary-foreground",
//                     "hover:bg-primary/80",
//                     "border-none font-medium",
//                   )}
//                 >
//                   {tag}
//                 </Badge>
//               ))}
//             </div>

//             <div className="flex gap-4">
//               <Button
//                 size="sm"
//                 className={cn("bg-primary text-primary-foreground", "hover:bg-primary/90", "border-none")}
//                 asChild
//               >
//                 <a href={project.github} target="_blank" rel="noopener noreferrer">
//                   <Github className="mr-2 h-4 w-4" />
//                   Code
//                 </a>
//               </Button>
//               <Button
//                 size="sm"
//                 className={cn("bg-secondary text-secondary-foreground", "hover:bg-secondary/90", "border-none")}
//                 asChild
//               >
//                 <a href={project.demo} target="_blank" rel="noopener noreferrer">
//                   <ExternalLink className="mr-2 h-4 w-4" />
//                   Demo
//                 </a>
//               </Button>
//             </div>
//           </motion.div>
//         </div>
//       </div>
//     </motion.div>
//   )
// }

// export function ProjectsSection() {
//   return (
//     <section
//       className={cn("min-h-screen py-24 relative overflow-hidden", "bg-gradient-to-b from-background to-background/95")}
//     >
//       {/* Background Effects */}
//       <div className="absolute inset-0">
//         <div className={cn("absolute inset-0", "bg-gradient-to-b from-primary/5 to-secondary/5")} />
//         <div
//           className="absolute inset-0 opacity-20"
//           style={{
//             backgroundImage: `radial-gradient(
//               circle at 2px 2px, 
//               hsl(var(--primary)/.2) 2px, 
//               transparent 0
//             )`,
//             backgroundSize: "32px 32px",
//           }}
//         />
//       </div>

//       <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
//         <motion.div
//           initial={{ opacity: 0, y: 20 }}
//           whileInView={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.5 }}
//           viewport={{ once: true }}
//           className="text-center mb-16"
//         >
//           <h2
//             className={cn(
//               "text-4xl font-bold",
//               "bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent",
//             )}
//           >
//             Projets Réalisés
//           </h2>
//           <p className="mt-4 text-lg text-muted-foreground">
//             Découvrez mes dernières réalisations en matière de DevOps et sécurité.
//           </p>
//         </motion.div>

//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 auto-rows-auto">
//           {projects.map((project, index) => (
//             <HologramProject key={project.title} project={project} index={index} />
//           ))}
//         </div>
//       </div>
//     </section>
//   )
// }

"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { 
  Github, 
  ExternalLink, 
  Maximize2, 
  Minus, 
  Folder, 
  FolderOpen, 
  File, 
  ChevronRight,
  Home,
  Search,
  RefreshCw,
  MoreVertical,
  Grid,
  List,
  Image as ImageIcon,
  FileText,
  Globe,
  X
} from "lucide-react"
import Image from "next/image"
import { cn } from "@/lib/utils"

const PLACEHOLDER_IMAGES = {
  visitbenin: "/images/visitbenin.png",
  agency: "/images/aas.png",
  frozen: "/images/congelato.png",
  incubator: "/images/incubator.png",
}

const projects = [
  {
    id: "visitbenin",
    title: "VisitBenin",
    description: "Plateforme de référencement des sites touristiques au bénin avec intégration d'un chatbot pour une expérience utilisateur interactive et personnalisée.",
    image: PLACEHOLDER_IMAGES.visitbenin,
    tags: ["Angular", "Cohere", "Laravel"],
    github: "#",
    demo: "https://visitbenin.djamal.site",
    date: "2023-05-15",
    files: [
      {
        id: "visitbenin-preview",
        title: "Aperçu.jpg",
        type: "image",
        content: PLACEHOLDER_IMAGES.visitbenin
      },
      {
        id: "visitbenin-desc",
        title: "Description.txt",
        type: "description",
        content: "Plateforme de référencement des sites touristiques au bénin avec intégration d'un chatbot pour une expérience utilisateur interactive et personnalisée."
      },
      {
        id: "visitbenin-site",
        title: "Site.url",
        type: "site",
        url: "https://visitbenin.djamal.site"
      }
    ]
  },
  {
    id: "agency",
    title: "MultiServices Agency",
    description: "Site vitrine moderne pour une agence multiservices spécialisée dans l'immobilier, la formation et la communication.",
    image: PLACEHOLDER_IMAGES.agency,
    tags: ["Next.js", "Tailwind CSS", "TypeScript"],
    github: "#",
    demo: "https://aas.djamal.site",
    date: "2023-08-22",
    files: [
      {
        id: "agency-preview",
        title: "Aperçu.jpg",
        type: "image",
        content: PLACEHOLDER_IMAGES.agency
      },
      {
        id: "agency-desc",
        title: "Description.txt",
        type: "description",
        content: "Site vitrine moderne pour une agence multiservices spécialisée dans l'immobilier, la formation et la communication."
      },
      {
        id: "agency-site",
        title: "Site.url",
        type: "site",
        url: "https://aas.djamal.site"
      }
    ]
  },
  // Ajoutez les autres projets de la même manière...
]

const FileIcon = ({ type }: { type: string }) => {
  switch(type) {
    case "image":
      return <ImageIcon className="w-5 h-5 text-green-500" />
    case "description":
      return <FileText className="w-5 h-5 text-blue-500" />
    case "site":
      return <Globe className="w-5 h-5 text-purple-500" />
    default:
      return <File className="w-5 h-5 text-gray-500" />
  }
}

const FileItem = ({ item, onOpen, selected }: { 
  item: any, 
  onOpen: (item: any) => void, 
  selected: boolean 
}) => {
  return (
    <div 
      className={cn(
        "flex items-center p-2 rounded hover:bg-accent cursor-pointer",
        selected && "bg-accent"
      )}
      onClick={() => onOpen(item)}
      onDoubleClick={() => {
        if (item.type === "site") {
          window.open(item.url, "_blank")
        } else {
          onOpen(item)
        }
      }}
    >
      <FileIcon type={item.type} />
      <span className="ml-2 truncate">{item.title}</span>
    </div>
  )
}

const FilePreview = ({ item, onClose, isExpanded, onToggleExpand }: { 
  item: any, 
  onClose: () => void,
  isExpanded: boolean,
  onToggleExpand: () => void
}) => {
  if (!item) return null

  return (
    <motion.div 
      className={cn(
        "fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4",
        isExpanded && "items-start pt-20"
      )}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div 
        className={cn(
          "bg-background rounded-lg shadow-xl overflow-hidden",
          isExpanded ? "w-full h-full max-w-none" : "w-full max-w-4xl max-h-[90vh]"
        )}
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
      >
        <div className="flex items-center justify-between border-b p-2">
          <div className="flex items-center">
            <FileIcon type={item.type} />
            <h3 className="ml-2 font-medium">{item.title}</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={onToggleExpand}
              className="p-1 hover:bg-accent rounded"
            >
              {isExpanded ? <Minus className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
            <button onClick={onClose} className="p-1 hover:bg-accent rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="p-6 overflow-auto h-full">
          {item.type === "image" ? (
            <div className="flex justify-center">
              <div className="relative w-full h-full min-h-[300px] max-h-[70vh]">
                <Image 
                  src={item.content} 
                  alt={item.title} 
                  fill 
                  className="object-contain"
                />
              </div>
            </div>
          ) : item.type === "description" ? (
            <div className="prose dark:prose-invert max-w-none">
              <pre className="whitespace-pre-wrap font-sans">{item.content}</pre>
            </div>
          ) : item.type === "site" ? (
            <div className="flex flex-col items-center justify-center h-full space-y-4">
              <Globe className="w-16 h-16 text-purple-500" />
              <h3 className="text-xl font-medium">Site Web Externe</h3>
              <p className="text-muted-foreground">Vous allez être redirigé vers :</p>
              <p className="text-primary font-mono">{item.url}</p>
              <Button asChild>
                <a href={item.url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Ouvrir le site
                </a>
              </Button>
            </div>
          ) : null}
        </div>
      </motion.div>
    </motion.div>
  )
}

export function ProjectsSection() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [selectedFile, setSelectedFile] = useState<any>(null)
  const [isExpanded, setIsExpanded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredProjects = projects.filter(project => 
    project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const currentProject = selectedProject 
    ? projects.find(p => p.id === selectedProject) 
    : null

  const handleOpenProject = (projectId: string) => {
    setSelectedProject(projectId === selectedProject ? null : projectId)
  }

  const handleOpenFile = (file: any) => {
    if (file.type === "site") {
      window.open(file.url, "_blank")
    } else {
      setSelectedFile(file)
    }
  }

  const toggleExpand = () => {
    setIsExpanded(!isExpanded)
  }

  return (
    <section className="min-h-screen py-8 relative">
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-[80vh] flex flex-col">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Explorateur de Projets
          </h2>
          <p className="mt-2 text-muted-foreground">
            Naviguez dans mes projets comme dans l&apos;Explorateur Windows
          </p>
        </motion.div>

        {/* Windows File Explorer UI */}
        <div className="flex-1 border rounded-lg overflow-hidden flex flex-col bg-background">
          {/* Toolbar */}
          <div className="border-b p-2 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <button className="p-1 hover:bg-accent rounded">
                <RefreshCw className="w-5 h-5" />
              </button>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Rechercher des projets..."
                  className="pl-8 pr-4 py-1 text-sm bg-input rounded-md w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setViewMode("grid")}
                className={cn(
                  "p-1 hover:bg-accent rounded",
                  viewMode === "grid" && "bg-accent"
                )}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setViewMode("list")}
                className={cn(
                  "p-1 hover:bg-accent rounded",
                  viewMode === "list" && "bg-accent"
                )}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-auto p-4">
            {viewMode === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProjects.map((project) => (
                  <div 
                    key={project.id}
                    className={cn(
                      "border rounded-lg p-4 flex flex-col items-center hover:bg-accent cursor-pointer",
                      selectedProject === project.id && "bg-accent"
                    )}
                    onClick={() => handleOpenProject(project.id)}
                  >
                    <FolderOpen className="w-16 h-16 text-yellow-400 mb-2" />
                    <h3 className="font-medium text-center truncate w-full">{project.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(project.date).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {filteredProjects.map((project) => (
                  <div key={project.id}>
                    <div 
                      className={cn(
                        "p-2 rounded flex items-center hover:bg-accent cursor-pointer",
                        selectedProject === project.id && "bg-accent"
                      )}
                      onClick={() => handleOpenProject(project.id)}
                    >
                      <Folder className="w-5 h-5 text-yellow-400 mr-2" />
                      <span>{project.title}</span>
                    </div>
                    {selectedProject === project.id && (
                      <motion.div 
                        className="ml-8 mt-1 space-y-1"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        {project.files.map((file: any) => (
                          <FileItem 
                            key={file.id}
                            item={file}
                            onOpen={handleOpenFile}
                            selected={selectedFile?.id === file.id}
                          />
                        ))}
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Status Bar */}
          <div className="border-t p-2 text-sm text-muted-foreground">
            {selectedProject 
              ? `${currentProject?.files.length} fichiers dans le dossier` 
              : `${filteredProjects.length} projets`}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedFile && (
          <FilePreview 
            item={selectedFile} 
            onClose={() => setSelectedFile(null)}
            isExpanded={isExpanded}
            onToggleExpand={toggleExpand}
          />
        )}
      </AnimatePresence>
    </section>
  )
}